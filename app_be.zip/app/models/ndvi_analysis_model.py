from pydantic import BaseModel

class NDVIAnalysisRequest(BaseModel):
    lat: float = 16.0544
    lng: float = 108.2022
    date: str = "2023-01-01"  # Dinh dang 'YYYY-MM-DD'
    cloud_cover: float = 20.0

class NDVIAnalysisResponse(BaseModel):
    lat: float
    lng: float
    date: str
    cloud_cover: float
    ndvi_local_url: str
    mean_ndvi: float | None = None
    min_ndvi: float | None = None
    max_ndvi: float | None = None
    vegetation_status: str | None = None