def ndvi_serial(ndvi_data) -> dict:
    return {
        "id": str(ndvi_data["_id"]) if ndvi_data.get("_id") else None,
        "lat": ndvi_data["lat"],
        "lng": ndvi_data["lng"],
        "date": ndvi_data["date"],
        "cloud_cover": ndvi_data["cloud_cover"],
        "ndvi_local_url": ndvi_data["ndvi_local_url"],
        "mean_ndvi": ndvi_data["mean_ndvi"],
        "min_ndvi": ndvi_data["min_ndvi"],
        "max_ndvi": ndvi_data["max_ndvi"],
        "vegetation_status": ndvi_data["vegetation_status"],
        "created_at": ndvi_data["created_at"],
    }