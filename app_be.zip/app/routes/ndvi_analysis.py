import calendar
from datetime import datetime, timezone

import ee
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from bson import ObjectId
from app.models.ndvi_analysis_model import (
    NDVIAnalysisRequest,
    NDVIAnalysisResponse,
)

from app.config.database import ndvi_collection
from app.schema.ndvi_schema import ndvi_serial
from app.utils.jwt import get_current_user
from app.utils.ndvi import _download_ndvi_image

router = APIRouter(prefix="/ndvi-analysis", tags=["NDVI Analysis"])

def _get_month_range(date_str: str) -> tuple[str, str]:
    parsed = datetime.strptime(date_str, "%Y-%m-%d").date()
    end_date = parsed
    start_month_index = (end_date.month - 1) - 6
    start_year = end_date.year + (start_month_index // 12)
    start_month = (start_month_index % 12) + 1
    last_day = calendar.monthrange(start_year, start_month)[1]
    start_day = min(end_date.day, last_day)
    start_date = end_date.replace(
        year=start_year,
        month=start_month,
        day=start_day,
    )
    return start_date.isoformat(), end_date.isoformat()

def classify_ndvi(mean_ndvi: float):
    if mean_ndvi is None:
        return "Không có dữ liệu"
    if mean_ndvi < 0:
        return "Không phải vùng thực vật hoặc có nước"
    elif mean_ndvi < 0.2:
        return "Thực vật rất thấp"
    elif mean_ndvi < 0.4:
        return "Thực vật thấp"
    elif mean_ndvi < 0.6:
        return "Thực vật trung bình"
    else:
        return "Thực vật tốt"


@router.post("/ndvi", response_class=JSONResponse)
async def perform_ndvi_analysis(
    payload: NDVIAnalysisRequest, 
    current_user: dict = Depends(get_current_user)
):
    try:
        payload_dict = payload.model_dump()
        start_date, end_date = _get_month_range(payload_dict["date"])
        
        point = ee.Geometry.Point([payload_dict["lng"], payload_dict["lat"]])

        region = point.buffer(2000).bounds()

        collection = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
                      .filterBounds(point)
                      .filterDate(start_date, end_date)
                      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', payload_dict["cloud_cover"]))
                    )

        image_count = collection.size().getInfo()
        print("lat:", payload_dict["lat"])
        print("lng:", payload_dict["lng"])
        print("date:", payload_dict["date"])
        print("start_date:", start_date)
        print("end_date:", end_date)
        print("cloud_cover:", payload_dict["cloud_cover"])
        print("image_count:", image_count)

        if image_count == 0:
            return JSONResponse(
                status_code=404,
                content={
                    "code": 404,
                    "message": "No Sentinel image found. Try increasing cloud_cover or changing date.",
                },
            )
        
        image = collection.median().clip(region)

        ndvi = image.normalizedDifference(["B8", "B4"]).rename("NDVI")

        stats = ndvi.reduceRegion(
                        reducer=ee.Reducer.mean()
                                .combine(ee.Reducer.min(), sharedInputs=True)
                                .combine(ee.Reducer.max(), sharedInputs=True),
                        geometry=region,
                        scale=10,
                        maxPixels=1e9
        ).getInfo()

        ndvi_vis = {
            "min": -0.2,
            "max": 0.8,
            "palette": [
            '#2c7bb6',
            '#d9d9d9',
            '#fdae61',
            '#fee08b',
            '#a6d96a',
            '#1a9641'
            ]
        }

        thumb_url = ndvi.getThumbURL({
            "dimensions": 1024,
            "region": region,
            "format": "png",
            **ndvi_vis
        })

        ndvi_local_url = _download_ndvi_image(thumb_url)

        response = NDVIAnalysisResponse(
            lat=payload_dict["lat"],
            lng=payload_dict["lng"],
            date=payload_dict["date"],
            cloud_cover=payload_dict["cloud_cover"],
            ndvi_local_url=ndvi_local_url,
            mean_ndvi=stats.get("NDVI_mean"),
            min_ndvi=stats.get("NDVI_min"),
            max_ndvi=stats.get("NDVI_max"),
            vegetation_status=classify_ndvi(stats.get("NDVI_mean")),
        ).model_dump()

        response["created_at"] = datetime.now(timezone.utc)
        response["user_id"] = ObjectId(current_user["sub"])
        result = ndvi_collection.insert_one(response)
        response["_id"] = result.inserted_id

        return {
            "code": 200,
            "message": "NDVI analysis successful",
            "data": ndvi_serial(response),
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "code": 500,
                "message": str(e)
            },
        )
    
@router.get("/ndvi")
def get_ndvi_analysis_by_user(
    current_user: dict = Depends(get_current_user),
):
    try:
        user_id = ObjectId(current_user["sub"])
    except Exception:
        return JSONResponse(
            status_code=401,
            content={
                "code": 401,
                "message": "Invalid token",
            },
        )

    ndvi_data_list = list(ndvi_collection.find({"user_id": user_id}).sort("created_at", -1))
    serialized_data = [ndvi_serial(ndvi_data) for ndvi_data in ndvi_data_list]

    return {
        "code": 200,
        "message": "NDVI analysis data retrieved successfully",
        "data": serialized_data,
    }

@router.delete("/ndvi/{ndvi_id}")
def delete_ndvi_analysis(
    ndvi_id: str,
    current_user: dict = Depends(get_current_user),
):
    try:
        user_id = ObjectId(current_user["sub"])
    except Exception:
        return JSONResponse(
            status_code=401,
            content={
                "code": 401,
                "message": "Invalid token",
            },
        )

    result = ndvi_collection.delete_one({"_id": ObjectId(ndvi_id), "user_id": user_id})
    if result.deleted_count == 0:
        return JSONResponse(
            status_code=404,
            content={
                "code": 404,
                "message": "NDVI analysis record not found",
            },
        )

    return {
        "code": 200,
        "message": "NDVI analysis record deleted successfully",
    }

@router.get("/ndvi/{ndvi_id}")
def get_ndvi_analysis_by_id(
    ndvi_id: str,
    current_user: dict = Depends(get_current_user),
):
    try:
        user_id = ObjectId(current_user["sub"])
    except Exception:
        return JSONResponse(
            status_code=401,
            content={
                "code": 401,
                "message": "Invalid token",
            },
        )

    ndvi_doc = ndvi_collection.find_one({"_id": ObjectId(ndvi_id), "user_id": user_id})
    if not ndvi_doc:
        return JSONResponse(
            status_code=404,
            content={
                "code": 404,
                "message": "NDVI analysis record not found",
            },
        )

    return {
        "code": 200,
        "message": "NDVI analysis record retrieved successfully",
        "data": ndvi_serial(ndvi_doc),
    }

@router.delete("/ndvi/{ndvi_id}")
def delete_ndvi_analysis(
    ndvi_id: str,
    current_user: dict = Depends(get_current_user),
):
    try:
        user_id = ObjectId(current_user["sub"])
    except Exception:
        return JSONResponse(
            status_code=401,
            content={
                "code": 401,
                "message": "Invalid token",
            },
        )

    result = ndvi_collection.delete_one({"_id": ObjectId(ndvi_id), "user_id": user_id})
    if result.deleted_count == 0:
        return JSONResponse(
            status_code=404,
            content={
                "code": 404,
                "message": "NDVI analysis record not found",
            },
        )

    return {
        "code": 200,
        "message": "NDVI analysis record deleted successfully",
    }