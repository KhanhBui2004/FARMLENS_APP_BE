import calendar
import os
import ee 
import numpy as np
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from bson import ObjectId
from app.models.sentinel_analysis_model import (
    SentinelAnalysisRequest,
    SentinelAnalysisResponse,
    SegmentationStatisticsRequest,
)
from app.schema import sentinel_serial, statistic_serial
from app.config.database import analysis_collection, statistics_collection
from app.utils.load_model import _segment_image_from_url
from app.utils.segmentation import _download_sentinel_image, decode_segmentation_url
from app.utils.gee import get_pixel_area_m2, get_region_area_m2
from app.utils.jwt import get_current_user


# Khởi tạo Earth Engine
json_path = "gee_key.json"

try:
    # Khởi tạo bằng Service Account
    credentials = ee.ServiceAccountCredentials(
        os.getenv("GEE_SERVICE_ACCOUNT"), # Copy email ở ảnh của bạn
        json_path
    )
    ee.Initialize(credentials)
except Exception as e:
    # Nếu chưa xác thực, hãy chạy 'earthengine authenticate' trong terminal
    raise Exception("Chưa xác thực GEE. Hãy chạy 'earthengine authenticate'")

router = APIRouter(prefix="/analysis", tags=["Analysis"])


CLASS_LABELS = [
    "agriculture",
    "barren",
    "forest",
    "rangeland",
    "unknown",
    "urban",
    "water",
]


CLASS_COLORS = [
    [255, 255, 100],  # Agriculture
    [210, 180, 140],  # Barren
    [0, 100, 0],      # Forest
    [124, 252, 0],    # Rangeland
    [0, 0, 0],        # Unknown
    [178, 34, 34],    # Urban
    [65, 105, 225],   # Water
]

def _get_month_range(date_str: str) -> tuple[str, str]:
    parsed = datetime.strptime(date_str, "%Y-%m-%d").date()
    end_date = parsed
    start_month_index = (end_date.month - 1) - 6
    start_year = end_date.year + (start_month_index // 12)
    start_month = (start_month_index % 12) + 1
    last_day = calendar.monthrange(start_year, start_month)[1]
    start_day = min(end_date.day, last_day)
    start_date = end_date.replace(
        year=start_year,
        month=start_month,
        day=start_day,
    )
    return start_date.isoformat(), end_date.isoformat()


@router.get("/segmentation")
def get_segmentation_history(
    current_user: dict = Depends(get_current_user),
):
    try:
        user_id = ObjectId(current_user["sub"])
    except Exception:
        return JSONResponse(
            status_code=401,
            content={
                "code": 401,
                "message": "Invalid token",
            },
        )

    analyses = list(analysis_collection.find({"user_id": user_id}))
    return {
        "code": 200,
        "message": "Segmentation history retrieved successfully",
        "data": [sentinel_serial(item) for item in analyses],
    }


@router.post("/segmentation")
def get_sentinel_image(
    payload: SentinelAnalysisRequest,
    current_user: dict = Depends(get_current_user),
):
    try:
        payload_dict = payload.model_dump()
        start_date, end_date = _get_month_range(payload_dict["date"])
        
        # 1. Xác định khu vực (Point)
        point = ee.Geometry.Point([payload_dict["lng"], payload_dict["lat"]])

        # 2. Lọc bộ dữ liệu Sentinel-2
        collection = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
                      .filterBounds(point)
                      .filterDate(start_date, end_date)
                      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', payload_dict["cloud_cover"]))
                      .sort('CLOUDY_PIXEL_PERCENTAGE'))

        image_count = collection.size().getInfo()
        print("lat:", payload_dict["lat"])
        print("lng:", payload_dict["lng"])
        print("date:", payload_dict["date"])
        print("start_date:", start_date)
        print("end_date:", end_date)
        print("cloud_cover:", payload_dict["cloud_cover"])
        print("image_count:", image_count)

        if image_count == 0:
            return JSONResponse(
                status_code=404,
                content={
                    "code": 404,
                    "message": "No Sentinel image found. Try increasing cloud_cover or changing date.",
                },
            )
        
        # 3. Lấy ảnh tốt nhất
        image = collection.median()

        # 4. Tham số hiển thị (Red, Green, Blue)
        vis_params = {
            'bands': ['B4', 'B3', 'B2'],
            'min': 0,
            'max': 3000,
            'gamma': 1.4
        }

        # 5. Tạo URL thumbnail
        # region_image = image.visualize(**vis_params) # Optional: visual
        region = point.buffer(2000).bounds()
        thumb_url = image.getThumbURL({
            'dimensions': 1024,
            'region': region, # 10km quanh điểm
            'format': 'png',
            **vis_params
        })

        region_area_m2 = get_region_area_m2(region)
        
        sentinel_local_url = _download_sentinel_image(thumb_url)
        segmentation_url = _segment_image_from_url(thumb_url)

        response = SentinelAnalysisResponse(
            lat=payload_dict["lat"],
            lng=payload_dict["lng"],
            date=end_date,
            cloud_cover=payload_dict["cloud_cover"],
            sentinel_url=sentinel_local_url,
            segmentation_url=segmentation_url,
            region_area_m2=region_area_m2,
        ).model_dump()
        response["created_at"] = datetime.now(timezone.utc)
        response["user_id"] = ObjectId(current_user["sub"])
        result = analysis_collection.insert_one(response)
        response["_id"] = result.inserted_id

        # Trả về URL ảnh
        return {
            "code": 200,
            "message": "Sentinel image retrieved successfully",
            "data": sentinel_serial(response)
        }

    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "code": 500,
                "message": str(e)
            }
        )

@router.delete("/segmentation/{analysis_id}")
def delete_segmentation(
    analysis_id: str,
    current_user: dict = Depends(get_current_user),
):
    try:
        user_id = ObjectId(current_user["sub"])
    except Exception:
        return JSONResponse(
            status_code=401,
            content={
                "code": 401,
                "message": "Invalid token",
            },
        )

    try:
        analysis_object_id = ObjectId(analysis_id)
    except Exception:
        return JSONResponse(
            status_code=400,
            content={
                "code": 400,
                "message": "Invalid analysis_id",
            },
        )

    result = analysis_collection.delete_one(
        {"_id": analysis_object_id, "user_id": user_id}
    )
    if result.deleted_count == 0:
        return JSONResponse(
            status_code=404,
            content={
                "code": 404,
                "message": "Segmentation not found",
            },
        )

    return {
        "code": 200,
        "message": "Segmentation deleted successfully",
    }


@router.delete("/segmentation")
def delete_all_segmentations(
    current_user: dict = Depends(get_current_user),
):
    try:
        user_id = ObjectId(current_user["sub"])
    except Exception:
        return JSONResponse(
            status_code=401,
            content={
                "code": 401,
                "message": "Invalid token",
            },
        )

    result = analysis_collection.delete_many({"user_id": user_id})
    if result.deleted_count == 0:
        return JSONResponse(
            status_code=404,
            content={
                "code": 404,
                "message": "No segmentations found",
            },
        )

    return {
        "code": 200,
        "message": "All segmentations deleted successfully",
        "deleted": result.deleted_count,
    }
    
@router.post("/statistics")
def get_statistics(
    payload: SegmentationStatisticsRequest,
    current_user: dict = Depends(get_current_user),
):
    try:
        if not payload.analysis_id:
            return JSONResponse(
                status_code=400,
                content={
                    "code": 400,
                    "message": "analysis_id is required",
                },
            )

        try:
            analysis = analysis_collection.find_one(
                {
                    "_id": ObjectId(payload.analysis_id),
                    "user_id": ObjectId(current_user["sub"]),
                }
            )
        except Exception:
            return JSONResponse(
                status_code=400,
                content={
                    "code": 400,
                    "message": "Invalid analysis_id",
                },
            )

        if not analysis:
            return JSONResponse(
                status_code=404,
                content={
                    "code": 404,
                    "message": "Analysis not found",
                },
            )

        segmentation_url = analysis.get("segmentation_url")
        region_area_m2 = analysis.get("region_area_m2")

        if segmentation_url is None or region_area_m2 is None:
            return JSONResponse(
                status_code=400,
                content={
                    "code": 400,
                    "message": "Analysis is missing segmentation data",
                },
            )

        image_array = decode_segmentation_url(segmentation_url)
        height, width, _ = image_array.shape
        total_pixels = height * width
        pixel_area_m2 = region_area_m2 / total_pixels
        pixel_area_km2 = float(pixel_area_m2) / 1_000_000.0

        class_stats = {}
        matched_pixels = 0
        for label, color in zip(CLASS_LABELS, CLASS_COLORS):
            color_array = np.array(color, dtype=np.uint8)
            mask = np.all(image_array == color_array, axis=-1)
            count = int(mask.sum())
            matched_pixels += count
            percentage = (count / total_pixels * 100.0) if total_pixels else 0.0
            area_km2 = count * pixel_area_km2
            class_stats[label] = {
                "pixel_count": count,
                "area_km2": round(area_km2, 6),
                "percentage": round(percentage, 4),
            }

        unmatched = total_pixels - matched_pixels
        statistics_doc = {
            "analysis_id": payload.analysis_id,
            "user_id": ObjectId(current_user["sub"]),
            "created_at": datetime.now(timezone.utc),
            "image_size": {"width": width, "height": height},
            "total_pixels": total_pixels,
            "unmatched_pixels": unmatched,
            "pixel_area_m2": pixel_area_m2,
            "region_area_m2": region_area_m2,
            "classes": class_stats,
        }
        result = statistics_collection.insert_one(statistics_doc)
        statistics_doc["_id"] = result.inserted_id
        return {
            "code": 200,
            "message": "Statistics retrieved successfully",
            "data": statistic_serial(statistics_doc)
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "code": 500,
                "message": str(e)
            }
        )
    
@router.get("/statistics")
def get_statistics_history(analysis_id: str):

    statistics = statistics_collection.find_one(
        {"analysis_id": analysis_id}
    )
    
    if not statistics:
        return JSONResponse(
            status_code=404,
            content={
                "code": 404,
                "message": "Statistics not found",
            },
        )
    return {
        "code": 200,
        "message": "Statistics retrieved successfully",
        "data": statistic_serial(statistics),
    }


@router.delete("/statistics/{analysis_id}")
def delete_statistics(analysis_id: str):

    result = statistics_collection.delete_many(
        {"analysis_id": analysis_id}
    )
    if result.deleted_count == 0:
        return JSONResponse(
            status_code=404,
            content={
                "code": 404,
                "message": "Statistics not found",
            },
        )

    return {
        "code": 200,
        "message": "Statistics deleted successfully",
    }


@router.delete("/statistics")
def delete_all_statistics(
    current_user: dict = Depends(get_current_user),
):
    try:
        user_id = ObjectId(current_user["sub"])
    except Exception:
        return JSONResponse(
            status_code=401,
            content={
                "code": 401,
                "message": "Invalid token",
            },
        )

    result = statistics_collection.delete_many({"user_id": user_id})
    if result.deleted_count == 0:
        return JSONResponse(
            status_code=404,
            content={
                "code": 404,
                "message": "No statistics found",
            },
        )

    return {
        "code": 200,
        "message": "All statistics deleted successfully",
        "deleted": result.deleted_count,
    }